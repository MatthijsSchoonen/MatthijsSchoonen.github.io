# Latchpoint Demo

Welcome to the Latchpoint Demo! This demo showcases the unique Latchpoint Gun and its evolving abilities across four levels.

## Controls

- **Movement:** `W`, `A`, `S`, `D`
- **Jump:** `Space`
- **Fire Latchpoint Gun:** Left Mouse Button
- **Interact (buttons, ride zipline):** `E`
- **Pick up Zipline:** `F`

## Latchpoint Gun Modes

Each level unlocks a new mode for the Latchpoint Gun:

| Level | Available Modes                |
|-------|-------------------------------|
| 1     | Grapple Mode                  |
| 2     | Grapple Mode, Pull Mode       |
| 3     | Grapple Mode, Pull Mode, Zipline Mode |
| 4     | Grapple Mode, Pull Mode, Zipline Mode, Fire Mode |

### Mode Details

- **Grapple Mode (1):** Swing or pull yourself to latch points.
- **Pull Mode (2):** Pull objects or yourself.
- **Zipline Mode (3):** Create and ride ziplines.
- **Fire Mode (5):** Fire projectiles (unlocked in level 4).
- **Connect Mode (4):** Not available in this demo.

## Tips

- Use `E` to interact with buttons and ride ziplines.
- Use `F` to pick up ziplines.
- Experiment with each mode as you unlock them in new levels.

Enjoy exploring the Latchpoint Demo!